/*	Programa: tipo_dato_caracter.c
	Descripcion: muestra las operaciones basicas con el tipo de dato caracter
*/
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

#define CONSTANTE_CARACTER 'a'

int main() {
	char caracter, resultado;
	/*Ingreso de Caracter*/
	printf("Ingrese un caracter:");
	scanf("%c",&caracter);
	/*Muestra de un Caracter*/
	printf("El caracter constante es el \'%c\':\n",CONSTANTE_CARACTER);

	printf("El caracter ingresado es el \'%c\':\n",caracter);
	
	/*Algunas Funciones*/
	printf("El caracter ingresado en mayusculas es el \'%c\':\n",toupper(caracter));
	printf("El caracter ingresado en minusculas es el \'%c\':\n",tolower(caracter));
	printf("El valor numerico del caracter \'%c\' es el : %d\n",caracter,caracter);
	resultado = toupper(caracter);
	printf("El valor numerico del caracter \'%c\' es el : %d\n",resultado,resultado);
	return 0;
}

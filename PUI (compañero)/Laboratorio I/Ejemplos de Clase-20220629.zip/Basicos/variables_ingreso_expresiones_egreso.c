/*	Programa: variables_ingreso_expresiones_egreso.c
	Descripcion: muestra las operaciones basicas que se realizan con variables
*/
#include <stdio.h>
#include <stdlib.h>

#define CONSTANTE 10
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int primerNumero, segundoNumero, resultado;
	/*Ingreso de los datos*/

	printf("Ingrese el primer numero:");
	scanf("%d",&primerNumero);
	printf("Ingrese el segundo numero:");
	scanf("%d",&segundoNumero);
	
	resultado = primerNumero / segundoNumero;
	
	printf("El resultado de %d / %d = %d\n",primerNumero, segundoNumero, resultado);
	printf("El resto de la division es %d\n",primerNumero % segundoNumero);
	printf("El producto entre %d y %d es %d\n", 10, 3, 10*3);
	printf("El producto entre %d y %d es %d\n", CONSTANTE, 5, CONSTANTE*5);

	return 0;
}
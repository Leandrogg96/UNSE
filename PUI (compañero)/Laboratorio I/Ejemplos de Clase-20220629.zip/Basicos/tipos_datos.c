/*	Programa: tipos_datos.c
	Descripcion: muestra las operaciones basicas con cada uno de los distintos tipos de datos
*/
#include <stdio.h>
#include <stdlib.h>

int main() {
	int entero, flotante, caracter;
	float promedioEdades;
	printf("Ingrese la primera edad:");
	scanf("%d",&edad1);
	printf("Ingrese la segunda edad:");
	scanf("%d",&edad2);
	sumaEdades=edad1+edad2;
	promedioEdades=sumaEdades/2.0f;
	printf("Edad1=%3d\n",edad1);
	printf("Edad2=%3d\n",edad2);
	printf("El promedio de las edades=%5.2f\n",promedioEdades);
	return 0;
}

/*	Programa: tipo_dato_entero.c
	Descripcion: muestra las operaciones basicas con el tipo de dato entero
*/
#include <stdio.h>
#include <stdlib.h>

#define CONSTANTE_ENTERA 300

int main() {
	int entero, primerOperando, segundoOperando, resultado;
	/*Ingreso de Numeros Enteros*/
	printf("Ingrese un numero:");
	scanf("%d",&entero);
	/*Muestra de un Numero Entero*/
	printf("El numero ingresado es el %d:\n",entero);
	/*Principales Operadores*/
	primerOperando = 1000;
	segundoOperando = CONSTANTE_ENTERA;
	resultado = primerOperando + segundoOperando;
	printf("Ejemplo de suma: %d + %d = %d\n",primerOperando,segundoOperando,resultado);
	
	resultado = primerOperando - segundoOperando;
	printf("Ejemplo de resta: %d - %d = %d\n",primerOperando,segundoOperando,resultado);
	
	resultado = primerOperando * segundoOperando;
	printf("Ejemplo de multiplicacion: %d * %d = %d\n",primerOperando,segundoOperando,resultado);
	
	resultado = primerOperando / segundoOperando;
	printf("Ejemplo de division: %d / %d = %d\n",primerOperando,segundoOperando,resultado);
	
	resultado = primerOperando % segundoOperando;
	printf("Ejemplo de resto: %d %% %d = %d\n",primerOperando,segundoOperando,resultado);
		
	
	return 0;
}

/*	Programa: tipo_dato_flotante.c
	Descripcion: muestra las operaciones basicas con el tipo de dato flotante
*/
#include <stdio.h>
#include <stdlib.h>

#define CONSTANTE_FLOTANTE 300.0f

int main() {
	float flotante, primerOperando, segundoOperando, resultado;
	/*Ingreso de Numeros Flotantes*/
	printf("Ingrese un numero:");
	scanf("%f",&flotante);
	/*Muestra de un Numero Flotante*/
	printf("El numero ingresado es el %f:\n",flotante);
	/*Principales Operadores*/
	primerOperando = 1000.0f;
	segundoOperando = CONSTANTE_FLOTANTE;
	resultado = primerOperando + segundoOperando;
	printf("Ejemplo de suma:\t\t %7.2f + %7.2f = %9.2f\n",primerOperando,segundoOperando,resultado);
	
	resultado = primerOperando - segundoOperando;
	printf("Ejemplo de resta:\t\t %7.2f - %7.2f = %9.2f\n",primerOperando,segundoOperando,resultado);
	
	resultado = primerOperando * segundoOperando;
	printf("Ejemplo de multiplicacion:\t %7.2f * %7.2f = %9.2f\n",primerOperando,segundoOperando,resultado);
	
	resultado = primerOperando / segundoOperando;
	printf("Ejemplo de division:\t\t %7.2f / %7.2f = %9.2f\n",primerOperando,segundoOperando,resultado);
	
	return 0;
}

/*
13 Mostrar el mayor y el menor de una serie de números enteros cuyo final viene dado por el ingreso del numero 0.
   Utilice en su solución las constantes INT_ MIN e INT_MAX.-
*/
#include<stdio.h>
#include <stdlib.h>
#include <limits.h>

int main (int argc, char*argv)
{
 int mayor = INT_MIN;
 int menor = INT_MAX;
 int n, numero;
 printf("Ingrese un numero (0 para terminar):");
 scanf("%d",&numero);
 while (numero !=0){
	if (numero > mayor)
		mayor = numero;
	if (numero < menor)
		menor = numero;
	printf("Ingrese un numero (0 para terminar):");
 	scanf("%d",&numero);
 }
 printf("El mayor valor ingresado es el %d\n", mayor);
 printf("El menor valor ingresado es el %d\n", menor);
 return 0;
}
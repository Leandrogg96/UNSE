/* 10. Mostrar todos los números pares desde el 0 hasta el 50.*/

#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int numero = 0;
	while (numero <=50){
		printf("%d - ",numero);
		numero = numero + 2;		
	}
			
	return 0;
}
/*
Dados dos números reales y un carácter que contiene la operación que desea realizar el usuario
con esos dos números (‘+’, ‘-‘, ‘*’ y ‘/’); a partir de ellos muestre tanto la operación como su resultado.
Ejemplo: si se introducen 14.25, 22.50 y el carácter ‘+’, el programa deberá sumar los valores
         y mostrar “14.25+22.50=36.75”.
*/

/*
1.- Ingreso los dos numeros y la operacion que quiere realizar el usuario
2.- En funcion de la operacion seleccionada por el usuario
    llevo a cabo la operacion seleccionada y muestro el resultado
*/
#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	/*1.- Ingreso los dos numeros y la operacion que quiere realizar el usuario*/
	float primerNumero, segundoNumero, resultado;
	char operacion;
	printf("Ingrese el primer numero:");
	scanf("%f",&primerNumero);
	printf("Ingrese el segundo numero:");
	scanf("%f",&segundoNumero);
	getchar();
	printf("Ingrese la operacion que desea realizar(+,-,*,/):");
	scanf("%c",&operacion);
	/*2.- En funcion de la operacion seleccionada por el usuario
	llevo a cabo la operacion seleccionada y muestro el resultado*/
	if (operacion == '+'){
		resultado = primerNumero + segundoNumero;
		printf("%.2f+%.2f=%.2f",primerNumero,segundoNumero,resultado);
	}
	else if (operacion == '-'){
		resultado = primerNumero - segundoNumero;
		printf("%.2f-%.2f=%.2f",primerNumero,segundoNumero,resultado);
	} else if (operacion == '*'){
		resultado = primerNumero * segundoNumero;
		printf("%.2f*%.2f=%.2f",primerNumero,segundoNumero,resultado);
	} else if (operacion == '/'){
		resultado = primerNumero / segundoNumero;
		printf("%.2f/%.2f=%.2f",primerNumero,segundoNumero,resultado);
	} else
		printf("Operacion no identificada");
			
	return 0;
}
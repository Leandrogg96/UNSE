/* 10. Mostrar todos los números pares desde el 0 hasta el 50.*/

#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int numero;
	for (numero = 0;numero <=50; numero += 2){
		printf("%d - ",numero);				
	}
			
	return 0;
}
/*
 * 8) Realizar un programa que acepte el ingreso de un código y,
 *    basado en el valor introducido y en la tabla que se muestra en el practico,
 *	  mostrar la capacidad de almacenamiento correcta de un pendrive.
 */

#include <stdio.h>
#include <stdlib.h>


int main(int argc, char** argv) {
    int codigo;
    printf("Ingrese el codigo:");
    scanf("%d",&codigo);
    switch(codigo){
        case '1':
            printf(" 2GB");
            break;
        case '2':
            printf(" 4GB");
            break;            
        case '3':
            printf("16GB");
            break;
        case '4':
            printf("32GB");
            break;     
        default:
            printf("Error en el codigo!!!!");
                    
    }
    return (EXIT_SUCCESS);
}

/* 11) Mostrar la tabla de multiplicar de un número entero positivo.*/

#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int numero, m;
	printf("Ingrese el numero de la tabla que quiere ver(2-9):");
	scanf("%d",&numero);
	
	printf("Tabla del %d\n",numero);
	for (m = 1;m <=10; m++){
		printf("%2d * %2d = %2d \n", m, numero, m * numero);		
	}
			
	return 0;
}

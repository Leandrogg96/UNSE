/*
Para N ternas de datos correspondientes a los empleados de una empresa:
DNI, Sexo (‘F’ - Femenino, ‘M’- Masculino) y DT (días trabajados),
y teniendo en cuenta que por cada día trabajado se abona $300, mostrar:
a) Cantidad de empleados mujeres que hayan trabajado menos de 20 días.
b) Sueldo promedio de los empleados varones.
c) Todos los datos de aquel empleado que tiene el mayor sueldo
d) Total que gasta la empresa en sueldos, discriminando además lo que gasta tanto en varones como en mujeres.
*/
#include <stdio.h>
#include <stdlib.h>

#define MONTO_DIARIO 300.0f

int main(int argc, char *argv[]) {
	int n, c, dni, diasTrabajados;
	int dniMayor, diasTrabajadosMayor;
	int cantidadMujeres=0, cantidadVarones=0;
	float sueldoEmpleado, sueldoPromedioVarones, mayorSueldo=0.0f;
	float totalSueldoVarones=0.0f, totalSueldoMujeres=0.0f, totalSueldosEmpresa=0.0f;
	char sexo, sexoMayor;
	printf("Ingrese la cantidad de empleados:");
	scanf("%d",&n);
	for (c=1;c<=n;c++){
		printf("Ingrese el dni:");
		scanf("%d",&dni);
		getchar();
		printf("Ingrese el sexo (F,M):");
		scanf("%c",&sexo);
		printf("Ingrese la cantidad de dias trabajados:");
		scanf("%d",&diasTrabajados);
	
		sueldoEmpleado = diasTrabajados * MONTO_DIARIO;
	
		if (sexo=='F' || sexo=='f') {
			if (diasTrabajados<20){
				cantidadMujeres++;
			}
			totalSueldoMujeres = totalSueldoMujeres + sueldoEmpleado;
		} else {
			totalSueldoVarones = totalSueldoVarones + sueldoEmpleado;
			cantidadVarones++;			
		}
				
		totalSueldosEmpresa = totalSueldosEmpresa + sueldoEmpleado;
		
		if (sueldoEmpleado > mayorSueldo){
			mayorSueldo = sueldoEmpleado;
			dniMayor = dni;
			sexoMayor = sexo;
			diasTrabajadosMayor = diasTrabajados;
		}
	}
	
	printf("\n\nLa cantidad de mujeres que trabajaron menos de 20 dias son: %d\n\n",cantidadMujeres);
	if (cantidadVarones !=0){
		sueldoPromedioVarones = totalSueldoVarones / cantidadVarones;
		printf("El sueldo promedio de los varones es $ %8.2f\n\n", sueldoPromedioVarones);		
	}else
		printf("El sueldo promedio de los varones es $ 0\n\n");
		
	printf("Datos del Mayor Sueldo\n");
	printf("----------------------\n");
	printf("Dni del Empleado: %d\n", dniMayor);
	printf("Sexo: %c\n", sexoMayor);
	printf("Dias Trabajados: %d\n", diasTrabajadosMayor);
	printf("Monto Sueldo: $ %8.2f\n", mayorSueldo);
	printf("\nEL gasto total en sueldos fue de $ %10.2f distribuidos en: \n", totalSueldosEmpresa);
	printf("Empleadas Mujeres: $ %10.2f\n", totalSueldoMujeres);
	printf("Empleados Varones: $ %10.2f\n", totalSueldoVarones);	
	return 0;
}
/* 11) Mostrar la tabla de multiplicar de un número entero positivo.*/

#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int numero, m;
	printf("Ingrese el numero de la tabla que quiere ver(2-9):");
	scanf("%d",&numero);
	
	printf("Tabla del %d\n",numero);
	m = 1;
	while (m <=10){
		printf("%2d * %2d = %2d \n", m, numero, m * numero);
		m++;		
	}
			
	return 0;
}
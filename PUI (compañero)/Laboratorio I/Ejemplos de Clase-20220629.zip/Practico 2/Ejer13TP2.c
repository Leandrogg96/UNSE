/*
13 Mostrar el mayor y el menor de una serie de N números enteros. Utilice en su solución las constantes INT_ MIN e INT_MAX.-
*/
#include<stdio.h>
#include <stdlib.h>
#include <limits.h>

int main (int argc, char*argv)
{
 int mayor = INT_MIN;
 int menor = INT_MAX;
 int n, contador, numero;
 printf("Ingrese el valor de N:");
 scanf("%d",&n);
 for (contador = 1; contador <= n; contador++){
 	printf("Ingrese el %d numero de la serie:",contador);
	scanf("%d",&numero);
	if (numero > mayor)
		mayor = numero;
	if (numero < menor)
		menor = numero;
 }
 printf("El mayor valor ingresado es el %d\n", mayor);
 printf("El menor valor ingresado es el %d\n", menor);
 return 0;
}
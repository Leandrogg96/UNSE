/*13c) Ingresar tres valores numéricos enteros, determinar el promedio y mostrar los valores originales
 y el promedio calculado.*/
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv ){
  int a, b, c;
  float promedio;
  printf("Ingrese el primer numero:");
  scanf("%d",&a);
  printf("Ingrese el segundo numero:");
  scanf("%d",&b);
  printf("Ingrese el tercer numero:");
  scanf("%d",&c);
  
  promedio = (a + b + c) / 3.0f;
  
  
  printf("Los valores ingresados son %d,%d,%d y su promedio %5.3f\n",a,b,c,promedio);
  return (EXIT_SUCCESS);
}
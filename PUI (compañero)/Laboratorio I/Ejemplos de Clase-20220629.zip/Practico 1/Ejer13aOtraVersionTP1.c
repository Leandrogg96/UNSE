/*13a) Convertir el valor de un número que representa los segundos en su equivalente en horas y minutos.*/
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv ){
  int segundos, minutos, horas;
  printf("Ingrese la cantidad de segundos:");
  scanf("%d",&segundos);
  minutos = segundos / 60;
  horas = minutos / 60;
  printf("Los %d segundos corresponden a %d minutos y a %d horas\n",segundos, minutos, horas);
  return (EXIT_SUCCESS);
}
/*13e) Mostrar los datos de tres personas con el siguiente formato:*/
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv ){
  printf("Apellido y Nombre \tEdad\tSueldo\n");	
  printf("---------------------------------------\n");
  printf("%s \t\t%3d \t%8.2f\n","Ariel Parra",25,7500.84);
  printf("%s \t\t%3d \t%8.2f\n","Mariela Diaz",17,18700.95);
  return (EXIT_SUCCESS);
}
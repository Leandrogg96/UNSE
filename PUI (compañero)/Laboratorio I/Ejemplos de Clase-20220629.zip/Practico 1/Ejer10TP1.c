/*10. Escribir un programa en C que almacene el valor entero 16 en la variable longitud
 y el valor entero 18 en la variable ancho.
 Luego calcular la variable perímetro usando la fórmula: perímetro = 2 × (largo + ancho)
 Usar la sentencia printf para mostrar el valor almacenado en la variable perímetro.
*/
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv ){
  int longitud = 16;
  int ancho = 18;
  int perimetro = 2 * (longitud + ancho);
  printf("El perimetro es %d\n",perimetro);
  return (EXIT_SUCCESS);
}
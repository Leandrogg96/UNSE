/*13a) Convertir el valor de un número que representa los segundos en su equivalente en horas y minutos.*/
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv ){
  int segundos, minutos, horas;
  printf("Ingrese la cantidad de segundos:");
  scanf("%d",&segundos);
  horas = segundos / 3600;
  minutos = (segundos % 3600) / 60;
  printf("Los %d segundos corresponden a %d horas con %d minutos\n",segundos, horas, minutos);
  return (EXIT_SUCCESS);
}